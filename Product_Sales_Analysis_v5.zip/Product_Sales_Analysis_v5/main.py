import os
import pandas as pd

def load_branch_data(branch):
    # Look for CSV inside data/ folder
    file_path = os.path.join("data", f"{branch}.csv")
    df = pd.read_csv(file_path)

    # Safe date parsing
    if "Date" in df.columns:
        df["Date"] = pd.to_datetime(df["Date"], errors="coerce", dayfirst=True)
        invalid_rows = df[df["Date"].isna()]
        if not invalid_rows.empty:
            print(f"⚠️ Found {len(invalid_rows)} invalid dates in {branch}.csv")

    if "Date" in df.columns:
        df["Month"] = df["Date"].dt.to_period("M").astype(str)

    return df


def get_monthly_summary(df, month):
    month_df = df[df["Month"] == month]
    top_products = (
        month_df.groupby("Product")["Units_Sold"]
        .sum()
        .sort_values(ascending=False)
        .reset_index()
    )
    least_products = top_products.sort_values(by="Units_Sold")
    return top_products, least_products, month_df


def suggest_stock(df, month):
    all_months = sorted(df["Month"].unique())
    if month not in all_months:
        return pd.DataFrame(columns=["Product", "Suggested_Stock"])

    idx = all_months.index(month)
    previous_months = all_months[max(0, idx - 3):idx]
    prev_data = df[df["Month"].isin(previous_months)]

    suggestion = (
        prev_data.groupby("Product")["Units_Sold"]
        .mean()
        .round()
        .reset_index()
    )
    suggestion.rename(columns={"Units_Sold": "Suggested_Stock"}, inplace=True)

    return suggestion
