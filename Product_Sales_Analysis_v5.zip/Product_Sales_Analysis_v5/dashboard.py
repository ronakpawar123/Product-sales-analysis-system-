import streamlit as st
import pandas as pd
import plotly.express as px
from main import load_branch_data

# =================================================
# PAGE CONFIG
# =================================================
st.set_page_config(
    page_title="Multi-Branch Product Sales Intelligence Dashboard",
    layout="wide",
    initial_sidebar_state="expanded"
)

# =================================================
# DARK THEME
# =================================================
st.markdown("""
<style>
body { background-color:#020617; }
.stMetric {
    background-color:#020617;
    padding:16px;
    border-radius:12px;
    border:1px solid #1f2937;
}
</style>
""", unsafe_allow_html=True)

st.title("📊 Multi-Branch Product Sales Intelligence Dashboard")

# =================================================
# LOGIN SYSTEM
# =================================================
users = pd.read_csv("users.csv")

if "logged_in" not in st.session_state:
    st.session_state.logged_in = False

if not st.session_state.logged_in:
    st.sidebar.title("🔐 Branch Login")
    username = st.sidebar.selectbox("Username", users["username"])
    password = st.sidebar.text_input("Password", type="password")

    if st.sidebar.button("Login"):
        row = users[(users["username"] == username) &
                    (users["password"] == password)]
        if not row.empty:
            st.session_state.logged_in = True
            st.session_state.branch = row.iloc[0]["branch"]
            st.rerun()
        else:
            st.error("Invalid credentials ❌")

# =================================================
# DASHBOARD
# =================================================
if st.session_state.logged_in:

    branch = st.session_state.branch
    df = load_branch_data(branch)

    # -------------------------------------------------
    # CLEAN MONTH REMOVE EXTRA 
    # -------------------------------------------------
    df["Month"] = pd.to_datetime(df["Month"], errors="coerce")
    df = df.dropna(subset=["Month"])
    df["Month"] = df["Month"].dt.strftime("%Y-%m")

    month_list = sorted(df["Month"].unique())
    selected_month = st.selectbox(
        "📅 Select Month",
        month_list,
        index=len(month_list) - 1
    )

    # -------------------------------------------------
    # FILTER DATA BY MONTH FIRST
    # -------------------------------------------------
    month_df = df[df["Month"] == selected_month].copy()

    # -------------------------------------------------
    # SIDEBAR CATEGORY FILTER (IMPORTANT)
    # -------------------------------------------------
    st.sidebar.markdown("## 🎛 Filters")
    selected_categories = st.sidebar.multiselect(
        "Filter by Category",
        month_df["Category"].unique(),
        default=month_df["Category"].unique()
    )

    month_df = month_df[month_df["Category"].isin(selected_categories)]

    # -------------------------------------------------
    # KPIs (NOW FILTER-AWARE)
    # -------------------------------------------------
    k1, k2, k3, k4 = st.columns(4)

    k1.metric("🛒 Total Units Sold", int(month_df["Units_Sold"].sum()))

    if not month_df.empty:
        best_product = (
            month_df.groupby("Product")["Units_Sold"]
            .sum()
            .idxmax()
        )
    else:
        best_product = "-"

    k2.metric("🔥 Best Product", best_product)

    k3.metric(
        "📦 Products Sold",
        month_df[month_df["Units_Sold"] > 0]["Product"].nunique()
    )

    k4.metric("📍 Branch", branch.upper())

    st.divider()

    # -------------------------------------------------
    # TOP & LEAST SELLING PRODUCTS (FILTERED)
    # -------------------------------------------------
    top = (
        month_df.groupby("Product")["Units_Sold"]
        .sum()
        .reset_index()
        .sort_values("Units_Sold", ascending=False)
    )

    least = (
        month_df.groupby("Product")["Units_Sold"]
        .sum()
        .reset_index()
        .sort_values("Units_Sold", ascending=True)
    )

    c1, c2 = st.columns(2)

    with c1:
        st.subheader("🔼 Top Selling Products")
        fig1 = px.bar(
            top.head(10),
            x="Product",
            y="Units_Sold",
            color="Units_Sold",
            color_continuous_scale="Greens"
        )
        fig1.update_layout(xaxis_tickangle=-45)
        st.plotly_chart(fig1, use_container_width=True)

    with c2:
        st.subheader("🔽 Least Selling Products")
        fig2 = px.bar(
            least.head(10),
            x="Product",
            y="Units_Sold",
            color="Units_Sold",
            color_continuous_scale="Reds"
        )
        fig2.update_layout(xaxis_tickangle=-45)
        st.plotly_chart(fig2, use_container_width=True)

    st.divider()

    # -------------------------------------------------
    # CATEGORY SHARE (FILTER-AWARE)
    # -------------------------------------------------
    st.subheader("📊 Category-wise Sales Distribution")

    category_summary = (
        month_df.groupby("Category")["Units_Sold"]
        .sum()
        .reset_index()
    )

    fig3 = px.pie(
        category_summary,
        names="Category",
        values="Units_Sold",
        hole=0.45,
        color_discrete_sequence=px.colors.sequential.RdBu
    )
    fig3.update_traces(textinfo="label+percent")
    st.plotly_chart(fig3, use_container_width=True)

    st.divider()

    # -------------------------------------------------
    # ⏰ EXPIRY PRODUCT ALERT
    # -------------------------------------------------
    st.subheader("⏰ Expiry Product Alert")

    if "Expiry_Month" in month_df.columns:
        month_df["Expiry_Month"] = pd.to_datetime(
            month_df["Expiry_Month"], errors="coerce"
        ).dt.strftime("%Y-%m")

        expiring_df = month_df[
            month_df["Expiry_Month"] == selected_month
        ][["Product", "Category", "Units_Sold"]]

        if not expiring_df.empty:
            st.warning("⚠️ Expiring products detected")
            st.dataframe(
                expiring_df.rename(
                    columns={"Units_Sold": "Expiring_Units_Sold"}
                ),
                use_container_width=True
            )
        else:
            st.success("✅ No products expiring this month.")
    else:
        st.info("ℹ️ Expiry data not available.")

    st.divider()

    # -------------------------------------------------
    # 📦 SMART STOCK RECOMMENDATION (CURRENT STOCK)
    # -------------------------------------------------
    st.subheader("📦 Smart Stock Recommendation")

    stock_df = (
        month_df.groupby("Product")["Units_Sold"]
        .sum()
        .reset_index()
        .rename(columns={"Units_Sold": "Total_Units_Sold"})
    )

    stock_df["Current_Stock"] = (stock_df["Total_Units_Sold"] * 0.6).round().astype(int)
    stock_df["Suggested_Stock"] = (
        stock_df["Total_Units_Sold"] * 1.25 - stock_df["Current_Stock"]
    ).round().astype(int)

    stock_df["Suggested_Stock"] = stock_df["Suggested_Stock"].apply(lambda x: max(x, 0))

    stock_df["Priority"] = stock_df["Suggested_Stock"].apply(
        lambda x: "🔥 High" if x >= 100 else "⚠️ Medium" if x >= 50 else "🟢 Low"
    )

    st.dataframe(
        stock_df[["Product", "Current_Stock", "Suggested_Stock", "Priority"]]
        .sort_values("Suggested_Stock", ascending=False),
        use_container_width=True
    )

    # -------------------------------------------------
    # LOGOUT
    # -------------------------------------------------
    if st.button("Logout 🔓"):
        st.session_state.logged_in = False
        st.rerun()
